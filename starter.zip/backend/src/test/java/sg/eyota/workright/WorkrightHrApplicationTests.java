package sg.eyota.workright;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkrightHrApplicationTests {

	@Test
	void contextLoads() {
	}

}
